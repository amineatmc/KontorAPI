﻿using Entities.Concrete;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Concrete.EntityFramework.Context
{
    public class KontorContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=DESKTOP-DITR34S;Database=kontorapi123;Trusted_Connection=true");
            // optionsBuilder.UseSqlServer("Data Source=DESKTOP-DITR34S;Integrated Security=True;")
        }
        public DbSet<Product> Products { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<PaymentType> PaymentType { get; set; }
        public DbSet<OperationClaim> OperationClaims { get; set; }
        public DbSet<UserOperationClaim> UserOperationClaims { get; set; }
        public DbSet<Invoice> Invoices { get; set; }
        public DbSet<Balance> Balances { get; set; }
        public DbSet<UserCredit> UserCredits { get; set; }
    }
}
