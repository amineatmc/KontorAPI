﻿using Core.DataAccess.EntityFramework;
using Core.Utilities.Results;
using DataAccess.Abstract;
using DataAccess.Concrete.EntityFramework.Context;
using Entities.Concrete;
using Entities.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Concrete.EntityFramework
{
    public class EfInvoiceDal : EfEntityRepositoryBase<Invoice, KontorContext>, IInvoiceDal
    {
        //    IInvoiceDal _invoiceDal;
        //    public EfInvoiceDal(IInvoiceDal invoiceDal)
        //    {
        //        _invoiceDal = invoiceDal;
        //    }
        //    public List<InvoiceDetailDto> GetAll(InvoiceDetailDto invoiceDetailDto)
        //    {
        //        using (KontorContext context = new KontorContext())
        //        {
        //            var result = from i in context.Invoices
        //                         join p in context.Products on i.ProductId equals p.ProductId
        //                         join u in context.PaymentType on i.PaymentTypeId equals u.Id
        //                         select new InvoiceDetailDto
        //                         {
        //                             //Id = i.Id,
        //                             Description = i.Description,
        //                             InvoiceDate = i.InvoiceDate,
        //                             Quantity = i.Quantity,
        //                             Status = i.Status,
        //                             Total = i.Total,
        //                             ProductId = p.ProductId,
        //                             PaymentTypeId = u.Id
        //                         };
        //            return result.ToList();
        //        }
        //    }

        public List<Invoice> GetAllBy(InvoiceDetailDto invoiceDetailDto)
        {
            using (KontorContext context = new KontorContext())
            {
                Expression<Func<Invoice, bool>> query = q =>
                   (invoiceDetailDto.Id != null ? q.Id.Equals(invoiceDetailDto.Id) : true)
                   && (invoiceDetailDto.Description != null ? q.Equals(invoiceDetailDto.Description) : true)
                   && (invoiceDetailDto.InvoiceDate != null ? q.Equals(invoiceDetailDto.InvoiceDate) : true)
                   && (invoiceDetailDto.PaymentTypeId != null ? q.Equals(invoiceDetailDto.PaymentTypeId) : true)
                   && (invoiceDetailDto.ProductId != null ? q.Equals(invoiceDetailDto.ProductId) : true)
                   && (invoiceDetailDto.Quantity != null ? q.Equals(invoiceDetailDto.Quantity) : true)
                   && (invoiceDetailDto.Status != null ? q.Equals(invoiceDetailDto.Status) : true)
                   && (invoiceDetailDto.Total != null ? q.Equals(invoiceDetailDto.Total) : true);

                //&& (vehicleInfoQuery.TaxiType != null ? q.TaxiTypeId == vehicleInfoQuery.TaxiType : true);
                return context.Set<Invoice>().Where(query).ToList();
            }
        }

        public List<InvoiceCountDto> GetInvoiceCount()
        {
            using (KontorContext context = new KontorContext())
            {
                return context.Invoices.GroupBy(i => i.Id)
                        .Select(i => new InvoiceCountDto
                        {
                            Id = i.Key,
                            InvoiceCount = i.Count()
                        }).ToList();
            }

        }

    }
}
