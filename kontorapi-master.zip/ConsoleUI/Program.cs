﻿using Business.Concrete;
using DataAccess.Abstract;

class Program
{
    static void Main(string[] args)
    {
     //   ProductTest();
        //CategoryTest();

    }
    //public static void ProductTest()
    //{
    //    ProductManager productManager = new ProductManager(new EfProductDal());
    //    foreach (var product in productManager.GetAll())
    //    {
    //        Console.WriteLine(product.ProductName + product.UnitPrice);
    //    }

    //}
}
