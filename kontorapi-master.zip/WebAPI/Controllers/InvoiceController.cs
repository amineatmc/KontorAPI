﻿using Business.Abstract;
using Core.Utilities.Results;
using Entities.Concrete;
using Entities.DTOs;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class InvoiceController : ControllerBase
    {
        IInvoiceService _invoiceService;

        public InvoiceController(IInvoiceService invoiceService)
        {
            _invoiceService = invoiceService;
        }

        [HttpGet("getall")]
        public IActionResult GetAll()//InvoiceDetailDto invoiceDetailDto
        {
            var result = _invoiceService.GetAll();//invoiceDetailDto
            if (result.Success)
            {
                return Ok(result);
            }
            return BadRequest(result.Message);
        }
        [HttpPost("add")]
        public IActionResult Add(InvoiceDetailDto invoiceDetailDto)
        {

            var result = _invoiceService.Add(invoiceDetailDto);
            if (result.Success)
            {
                return Ok(result);
            }
            return BadRequest(result.Message);
        }

        [HttpGet("getbyid")]
        public IActionResult GetByInvoiceId(int id)
        {
            var result = _invoiceService.GetByInvoiceId(id);
            if (result.Success)
            {
                return Ok(result.Data);
            }
            return BadRequest(result);
        }
        [HttpPost("getallbyquery")]
        public IActionResult GetAllBy([FromBody] InvoiceDetailDto invoiceDetailDto)
        {
            var result = _invoiceService.GetAllBy(invoiceDetailDto);
            if (result.Success)
            {
                return Ok(result);
            }
            return BadRequest(result);
        }

        [HttpGet("getinvoicescount")]
        public IActionResult GetInvoiceCount()
        {
            var result = _invoiceService.GetInvoiceCount();
            if (result.Success)
            {
                return Ok(result);
            }
            return BadRequest(result);
        }
    }
}
