﻿using Business.Abstract;
using Core.Utilities.Results;
using Entities.Concrete;
using Entities.DTOs;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        IOrderService _orderService;

        public OrderController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        //[HttpPost("getall")]
        //public IActionResult GetAllByInfoQuery([FromBody] OrderDetailDto orderDetailDto)
        //{
        //    var result = _orderService.GetAllByInfoQuery(orderDetailDto);
        //    if (result.Success)
        //    {
        //        return Ok(result);
        //    }
        //    return BadRequest(result);
        //}
        [HttpPost("getall")]
        public IActionResult GetAll(OrderDetailDto orderDetailDto)
        {
            var result = _orderService.GetAll(orderDetailDto);
            if (result.Success)
            {
                return Ok(result);
            }
            return BadRequest(result);
        }

        [HttpGet("getbyorderid")]
        public IActionResult GetByOrderId(int id)
        {
            var result = _orderService.GetByOrderId(id);

            if (result.Success)
            {
                return Ok(result);
            }
            return BadRequest(result.Message);
        }
        [HttpGet("getbyuserid")]
        public IActionResult GetByUserId(int id)
        {
            var result = _orderService.GetByUserId(id);
            //var result = new Result(true, null);
            if (result.Success)
            {
                return Ok(result);
            }
            return BadRequest(result.Message);
        }        
        [HttpPost("add")]
        public IActionResult Add(Order order)
        {
             int userId = string.IsNullOrWhiteSpace(User.FindFirst(ClaimTypes.NameIdentifier).Value) == false ? Convert.ToInt32(User.FindFirst(ClaimTypes.NameIdentifier).Value) : 0;
             string userName = User.FindFirst(ClaimTypes.Name).Value ;
            //Invoice invoice=new Invoice();
            //int userId = User.FindFirst(ClaimTypes.NameIdentifier).Value);

            var result = _orderService.Add(order,userName);
            if (result.Success)
            {
                return Ok(result);                
            }
            return BadRequest(result.Message);
        }
    }
}
//ProductId, UserId, AddedUserId, Credit, Note, Date