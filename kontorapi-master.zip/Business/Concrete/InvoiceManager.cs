﻿using Business.Abstract;
using Business.Constant;
using Core.Utilities.Results;
using DataAccess.Abstract;
using DataAccess.Concrete.EntityFramework;
using Entities.Concrete;
using Entities.DTOs;

namespace Business.Concrete
{
    public class InvoiceManager : IInvoiceService
    {
        private readonly IInvoiceDal _invoiceDal;
        private readonly IProductService productService;


        public InvoiceManager(IInvoiceDal invoiceDal, IProductService productService)
        {
            _invoiceDal = invoiceDal;
            this.productService = productService;
        }
        public IDataResult<Invoice> GetByInvoiceId(int id)
        {
            return new SuccessDataResult<Invoice>(_invoiceDal.Get(i => i.Id == id));
        }
        public IResult Add(InvoiceDetailDto invoiceDetailDto)
        {

            var productResult = this.productService.GetById(invoiceDetailDto.ProductId);
            if (!productResult.Success)
            {
                return new ErrorResult("Hatalı ProductId değeri");
            }
            invoiceDetailDto.Total = productResult.Data.UnitPrice * invoiceDetailDto.Quantity;
            var invoice = new Invoice()
            {
                //Id = invoiceDetailDto.Id,
                ProductId = invoiceDetailDto.ProductId,
                Quantity = invoiceDetailDto.Quantity,
                PaymentTypeId = invoiceDetailDto.PaymentTypeId,
                Description = invoiceDetailDto.Description,
                Total = invoiceDetailDto.Total,
                Status = invoiceDetailDto.Status,
                InvoiceDate = invoiceDetailDto.InvoiceDate
            };
            _invoiceDal.Add(invoice);
            return new SuccessResult();
        }
        public IDataResult<List<Invoice>> GetAll()//InvoiceDetailDto invoiceDetailDto
        {
            return new SuccessDataResult<List<Invoice>>(_invoiceDal.GetAll());
        }

        public IDataResult<PagedModel<List<Invoice>>> GetAllBy(InvoiceDetailDto invoiceDetailDto)
        {
            int pageNumber = (int)(invoiceDetailDto?.Pagination?.PageNumber != null ? invoiceDetailDto.Pagination.PageNumber : 1);
            int pageSize = (int)(invoiceDetailDto?.Pagination?.PageSize != null ? invoiceDetailDto.Pagination.PageSize : 10);
            pageNumber = pageNumber > 0 ? pageNumber : 1;
            pageSize = pageSize > 0 ? pageSize : 10;
            int start = (int)((pageNumber - 1) * pageSize);

            var invoices = _invoiceDal.GetAllBy(invoiceDetailDto).Skip(start).Take(pageSize).ToList();
            var totalRecords = _invoiceDal.GetAllBy(invoiceDetailDto).Count();

            if (totalRecords == 0)
            {
                return new SuccessDataResult<PagedModel<List<Invoice>>>("Empty List");
            }
            else if (invoices.Count == 0)
            {
                return new ErrorDataResult<PagedModel<List<Invoice>>>("Wrong Page Settings");
            }
            return new SuccessDataResult<PagedModel<List<Invoice>>>(new PagedModel<List<Invoice>>(invoices, totalRecords, pageNumber, pageSize), Messages.Success);
        }


        public IDataResult<List<InvoiceCountDto>> GetInvoiceCount()
        {
            var result = _invoiceDal.GetInvoiceCount();
            int totalCount = 0;
            foreach (var item in result)
            {
                totalCount += item.InvoiceCount;
            }
            var totalDto = new InvoiceCountDto()
            {
                InvoiceCount = totalCount,
                Id = 1
            };
            result.Add(totalDto);

            return new SuccessDataResult<List<InvoiceCountDto>>(result);
        }
    }
}
