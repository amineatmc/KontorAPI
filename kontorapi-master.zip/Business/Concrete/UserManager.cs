﻿using Business.Abstract;
using Business.BusinessAspects.Autofac;
using Core.Utilities.Business;
using Core.Utilities.Results;
using DataAccess.Abstract;
using Entities.Concrete;
using Entities.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Concrete
{
    public class UserManager : IUserService
    {
        IUserDal _userDal;

        public UserManager(IUserDal userDal)
        {
            _userDal = userDal;
        }
        
        public List<OperationClaim> GetClaims(User user)
        {
            return _userDal.GetClaims(user);
        }
        public List<OperationClaim> GetUserEmail(User user)
        {
            return _userDal.GetClaims(user);
        }

        public void Add(User user)
        {
            _userDal.Add(user);
        }

        public User GetByMail(string email)
        {
            return _userDal.Get(u => u.Email == email);
        }
        [SecuredOperation("product.add,admin")]
        public List<User> GetAll()
        {
            return _userDal.GetAll(); 
        }
        // [SecuredOperation("product.add,admin")]
        //public IResult DeclareCredit(UserForCreditDto userForCreditDto)
        //{
        //    IResult result = BusinessRules.Run(CheckIfCreditEqualsZero(userForCreditDto.Credit));
        //    if (result != null)
        //    {
        //        return result;
        //    }

        //user userforupdate = _userdal.get(u => u.ıd == userforcreditdto.ıd);
        //userforupdate.credit += userforcreditdto.credit;
        //    _userdal.update(userforupdate);
    //        return new successresult();
    //}

    //private IResult CheckIfCreditEqualsZero(int credit)
    //{
    //    return credit != 0 ?
    //        new SuccessResult() :
    //        new ErrorResult("Kredi miktarı sıfır olamaz");
    //}
}
}
