﻿using Business.Abstract;
using Core.Utilities.Results;
using DataAccess.Abstract;
using Entities.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Concrete
{
    public class IUserCreditManager : IUserCreditService
    {
        IUserCreditDal _userCreditDal;
        public IUserCreditManager(IUserCreditDal userCreditDal)
        {
            _userCreditDal = userCreditDal;
        }
        public IResult Add(UserCredit userCredit)
        {
            UserCredit userforupdate = _userCreditDal.Get(u => u.Id == userforcreditdto.ıd);
            userforupdate.credit += userforcreditdto.credit;
            _userdal.update(userforupdate);
        }

       
    }
}
