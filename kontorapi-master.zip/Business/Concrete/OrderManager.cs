﻿using Business.Abstract;
using Business.Constant;
using Core.Utilities.Business;
using Core.Utilities.Results;
using DataAccess.Abstract;
using Entities.Concrete;
using Entities.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;


namespace Business.Concrete
{
    public class OrderManager : IOrderService
    {       
        private readonly IOrderDal _orderDal;
        private readonly IUserService _userService;
        private readonly IUserDal _userDal;
        private readonly IInvoiceDal _invoiceDal;
        private readonly IProductService productService;
        private readonly IAuthService _authService;
        private readonly IBalanceDal _balanceDal;
        private readonly IUserService userService;
        private readonly IInvoiceService invoiceService;
        private readonly IUserCreditDal _userCreditDal;

        public OrderManager(IOrderDal orderDal, IProductService productService,IUserService userService,
            IInvoiceDal invoiceDal,IAuthService authService, IUserDal userDal,IBalanceDal balanceDal,IInvoiceService invoiceService,IUserCreditDal userCreditDal)
        {
            _orderDal = orderDal;
            _userDal = userDal;
            this.productService = productService;
            _userService = userService;
            _invoiceDal = invoiceDal;
            _authService = authService;
            _balanceDal = balanceDal;
            this.invoiceService = invoiceService;
            _userCreditDal = userCreditDal;
        }
        public IResult Add(Order order,string userName)
        {
            var invoiceState = this.invoiceService.GetByInvoiceId(order.InvoiceId);
            if (invoiceState.Data.Status == true)
            {
                var productResult = this.productService.GetById(order.ProductId);
            if (!productResult.Success)
            {
                return new ErrorResult("Hatalı ProductId değeri");
            }
            order.Total = productResult.Data.UnitPrice * order.Quantity;
            _orderDal.Add(order);

            Balance balance = new Balance()
            {
                PaymentTypeId = order.PaymentTypeId,
                Count = order.Quantity,
                DeclareUserName = userName,
                ReceiveUserName = userName,
                CreateDate = order.OrderDate
            };
            _balanceDal.Add(balance);
                //UserCredit userCredit = new UserCredit()
                //{
                //    UserId = order.UserId,
                //    Credits = order.Quantity
                //};
                //_userCreditDal.Add(userCredit);
            return new SuccessResult();
            }
            else
                {
                    return new ErrorResult("ödeme başarısız");
                }
            }
        public IDataResult<List<Order>> GetByOrderId(int id)
        {
            return new SuccessDataResult<List<Order>>(_orderDal.GetAll(o => o.OrderId == id));
        }
        public IDataResult<List<Order>> GetByUserId(int id)
        {
              return new SuccessDataResult<List<Order>>(_orderDal.GetAll(o => o.UserId == id));
        }
        //private IResult CheckIfCredit(bool status)
        //{
        //    return status != true ?
        //        new SuccessResult() :
        //        new ErrorResult("AA");
        //}
        //public IDataResult/*<PagedModel*/<List<Order>> GetAllByInfoQuery(OrderDetailDto orderDetailDto)
        //{
        //    int pageNumber = (int)(orderDetailDto?.Pagination?.PageNumber != null ? orderDetailDto.Pagination.PageNumber : 1);
        //    int pageSize = (int)(orderDetailDto?.Pagination?.PageSize != null ? orderDetailDto.Pagination.PageSize : 10);
        //    pageNumber = pageNumber > 0 ? pageNumber : 1;
        //    pageSize = pageSize > 0 ? pageSize : 10;
        //    int start = (int)((pageNumber - 1) * pageSize);

        //    var orders = _orderDal.GetAllByInfoQuery(orderDetailDto).Skip(start).Take(pageSize).ToList();
        //    var totalRecords = _orderDal.GetAllByInfoQuery(orderDetailDto).Count();

        //    if (totalRecords == 0)
        //    {
        //        return new SuccessDataResult/*<PagedModel*/<List<Order>>("Empty List");
        //    }
        //    else if (orders.Count == 0)
        //    {
        //        return new ErrorDataResult/*<PagedModel*/<List<Order>>("Wrong Page Settings");
        //    }
        //    return new SuccessDataResult/*<PagedModel*/<List<Order>>(/*new PagedModel<List<Order>>(orders, totalRecords, pageNumber, pageSize)*/orders, Messages.Success);
        //}

        public IDataResult<List<OrderCountDto>> GetOrdersCount()
        {
            var result = _orderDal.GetOrderCount();           
            int totalCount = 0;
            foreach (var item in result)
            {
                totalCount += item.OrderCount;
            }
            var totalDto = new OrderCountDto() { OrderCount = totalCount, OrderId = 1 };
            result.Add(totalDto);

            return new SuccessDataResult<List<OrderCountDto>>(result);
        }

        public IDataResult<List<OrderDetailDto>> GetAll(OrderDetailDto orderDetailDto)
        {
            return new SuccessDataResult<List<OrderDetailDto>>(_orderDal.GetAll());
        }

        
    }
}
