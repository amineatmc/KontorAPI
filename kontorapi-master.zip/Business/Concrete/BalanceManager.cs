﻿using Business.Abstract;
using Core.Utilities.Results;
using DataAccess.Abstract;
using Entities.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Concrete
{
    public class BalanceManager : IBalanceService
    {
        private readonly IBalanceDal _balanceDal;
        private readonly IOrderDal _orderDal;
        private readonly IUserCreditDal _userCreditDal;

        public BalanceManager(IBalanceDal balanceDal,IUserCreditDal userCreditDal)
        {
            _balanceDal = balanceDal;
            _userCreditDal = userCreditDal;
        }
        public IResult Add(Balance balance)
        {
             _balanceDal.Add(balance);        
            return new SuccessResult();
        }
    }
}
