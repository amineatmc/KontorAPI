﻿using Core.Utilities.Results;
using Entities.Concrete;
using Entities.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Abstract
{
    public interface IInvoiceService
    {
        IDataResult<List<Invoice>> GetAll();//InvoiceDetailDto invoiceDetailDto
        IResult Add(InvoiceDetailDto invoiceDetailDto);
        IDataResult<Invoice> GetByInvoiceId(int id);
        IDataResult<PagedModel<List<Invoice>>> GetAllBy(InvoiceDetailDto invoiceDetailDto);
        IDataResult<List<InvoiceCountDto>> GetInvoiceCount();

    }
}
