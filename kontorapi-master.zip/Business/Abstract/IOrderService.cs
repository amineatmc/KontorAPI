﻿using Core.Utilities.Results;
using Entities.Concrete;
using Entities.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Abstract
{
    public interface IOrderService
    {
        //IDataResult/*<PagedModel*/<List<Order>> GetAllByInfoQuery(OrderDetailDto orderDetailDto);
        IDataResult<List<OrderDetailDto>> GetAll(OrderDetailDto orderDetailDto);
        IDataResult<List<OrderCountDto>> GetOrdersCount();

        //IDataResult<List<OrderDetailDto>> GetOrderDetails();
        IResult Add(Order order, string userName);
        IDataResult<List<Order>> GetByOrderId(int id);
        IDataResult<List<Order>> GetByUserId(int id);


    }
}
